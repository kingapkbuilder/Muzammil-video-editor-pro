# Premiere Mobile Pro - Multilayer Video Editor for Android & Web
🎬 **Adobe Premiere Pro Jaisa Multilayer Video Editor (Chroma Key + Animations + Lumetri Color + Offline PWA + Android APK Workflow)**

## 🚀 Key Features:
- **Portrait & Landscape Ergonomics**: Edit comfortably on phone vertically or switch to wide landscape NLE.
- **Chroma Key (Green Screen Removal)**: Instant background removal for PIP & overlays with tolerance & edge feathering.
- **Animation Suite**: Keyframe motion graphics: Fade In, Bounce In, Zoom In, Slide Up/Down/Left/Right, Spin, Pulse, Float, Shake, Ken Burns.
- **Lumetri Color Grading**: 1-Click LUTs (Teal & Orange, Vintage, Noir, Cyberpunk, Golden Hour) + Temperature, Tint, Highlights, Shadows, Vignette.
- **Multilayer Timeline**: V1, V2, T1, A1, A2 multi-track editing with razor split, trim handles, and snapping.
- **100% Offline PWA**: Works with Airplane mode enabled.
- **Project Export**: Download and import `.prproj` sequences anytime.
- **Automated Android APK Build**: GitHub Actions workflow generates direct `app-debug.apk`.

## 📱 How to Get Android APK via GitHub Actions:
1. Push this repository to your GitHub.
2. The GitHub Actions workflow (`.github/workflows/android-apk.yml`) will build your Android APK.
3. Download the APK from the GitHub Actions Artifacts tab on your phone and install!
